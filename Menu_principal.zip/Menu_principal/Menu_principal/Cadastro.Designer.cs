﻿/*
 * Created by SharpDevelop.
 * User: Aluno
 * Date: 06/10/2025
 * Time: 14:42
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Menu_principal
{
	partial class Cadastro
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.cbx_serie = new System.Windows.Forms.ComboBox();
			this.txtbx_senha = new System.Windows.Forms.TextBox();
			this.txtbx_usuario = new System.Windows.Forms.TextBox();
			this.btn_criarconta = new System.Windows.Forms.Button();
			this.btn_login = new System.Windows.Forms.Button();
			this.lbl_usuario2 = new System.Windows.Forms.Label();
			this.lbl_senha = new System.Windows.Forms.Label();
			this.lbl_serie = new System.Windows.Forms.Label();
			this.lbl_titulo2 = new System.Windows.Forms.Label();
			this.lbl_dica = new System.Windows.Forms.Label();
			this.txtbx_dica = new System.Windows.Forms.TextBox();
			this.lbl_conselho = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.SuspendLayout();
			// 
			// cbx_serie
			// 
			this.cbx_serie.FormattingEnabled = true;
			this.cbx_serie.Items.AddRange(new object[] {
									"1º Ano EM",
									"2º Ano EM",
									"3º Ano EM"});
			this.cbx_serie.Location = new System.Drawing.Point(287, 385);
			this.cbx_serie.Margin = new System.Windows.Forms.Padding(2);
			this.cbx_serie.Name = "cbx_serie";
			this.cbx_serie.Size = new System.Drawing.Size(586, 21);
			this.cbx_serie.TabIndex = 0;
			this.cbx_serie.SelectedIndexChanged += new System.EventHandler(this.ComboBox1SelectedIndexChanged);
			// 
			// txtbx_senha
			// 
			this.txtbx_senha.Location = new System.Drawing.Point(287, 233);
			this.txtbx_senha.Margin = new System.Windows.Forms.Padding(2);
			this.txtbx_senha.Multiline = true;
			this.txtbx_senha.Name = "txtbx_senha";
			this.txtbx_senha.PasswordChar = '#';
			this.txtbx_senha.Size = new System.Drawing.Size(586, 45);
			this.txtbx_senha.TabIndex = 7;
			// 
			// txtbx_usuario
			// 
			this.txtbx_usuario.Location = new System.Drawing.Point(287, 155);
			this.txtbx_usuario.Margin = new System.Windows.Forms.Padding(2);
			this.txtbx_usuario.Multiline = true;
			this.txtbx_usuario.Name = "txtbx_usuario";
			this.txtbx_usuario.Size = new System.Drawing.Size(586, 42);
			this.txtbx_usuario.TabIndex = 6;
			// 
			// btn_criarconta
			// 
			this.btn_criarconta.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.btn_criarconta.Font = new System.Drawing.Font("Trebuchet MS", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btn_criarconta.Location = new System.Drawing.Point(491, 456);
			this.btn_criarconta.Margin = new System.Windows.Forms.Padding(2);
			this.btn_criarconta.Name = "btn_criarconta";
			this.btn_criarconta.Size = new System.Drawing.Size(176, 50);
			this.btn_criarconta.TabIndex = 9;
			this.btn_criarconta.Text = "Criar conta";
			this.btn_criarconta.UseVisualStyleBackColor = false;
			this.btn_criarconta.Click += new System.EventHandler(this.Btn_criarcontaClick);
			// 
			// btn_login
			// 
			this.btn_login.BackColor = System.Drawing.SystemColors.ControlLightLight;
			this.btn_login.Font = new System.Drawing.Font("Trebuchet MS", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btn_login.ForeColor = System.Drawing.SystemColors.ControlText;
			this.btn_login.Location = new System.Drawing.Point(11, 550);
			this.btn_login.Margin = new System.Windows.Forms.Padding(2);
			this.btn_login.Name = "btn_login";
			this.btn_login.Size = new System.Drawing.Size(211, 51);
			this.btn_login.TabIndex = 10;
			this.btn_login.Text = "Voltar ao Login";
			this.btn_login.UseVisualStyleBackColor = false;
			this.btn_login.Click += new System.EventHandler(this.Btn_loginClick);
			// 
			// lbl_usuario2
			// 
			this.lbl_usuario2.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_usuario2.Location = new System.Drawing.Point(159, 155);
			this.lbl_usuario2.Name = "lbl_usuario2";
			this.lbl_usuario2.Size = new System.Drawing.Size(123, 42);
			this.lbl_usuario2.TabIndex = 11;
			this.lbl_usuario2.Text = "Usuário:";
			// 
			// lbl_senha
			// 
			this.lbl_senha.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_senha.Location = new System.Drawing.Point(180, 236);
			this.lbl_senha.Name = "lbl_senha";
			this.lbl_senha.Size = new System.Drawing.Size(102, 42);
			this.lbl_senha.TabIndex = 12;
			this.lbl_senha.Text = "Senha:";
			// 
			// lbl_serie
			// 
			this.lbl_serie.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_serie.Location = new System.Drawing.Point(194, 373);
			this.lbl_serie.Name = "lbl_serie";
			this.lbl_serie.Size = new System.Drawing.Size(88, 42);
			this.lbl_serie.TabIndex = 13;
			this.lbl_serie.Text = "Série:";
			// 
			// lbl_titulo2
			// 
			this.lbl_titulo2.BackColor = System.Drawing.Color.SteelBlue;
			this.lbl_titulo2.Font = new System.Drawing.Font("Cooper Black", 62.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_titulo2.Location = new System.Drawing.Point(349, 9);
			this.lbl_titulo2.Name = "lbl_titulo2";
			this.lbl_titulo2.Size = new System.Drawing.Size(450, 100);
			this.lbl_titulo2.TabIndex = 14;
			this.lbl_titulo2.Text = "Cadastro!";
			// 
			// lbl_dica
			// 
			this.lbl_dica.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_dica.Location = new System.Drawing.Point(194, 314);
			this.lbl_dica.Name = "lbl_dica";
			this.lbl_dica.Size = new System.Drawing.Size(88, 42);
			this.lbl_dica.TabIndex = 16;
			this.lbl_dica.Text = "Dica:";
			this.lbl_dica.Click += new System.EventHandler(this.Label1Click);
			// 
			// txtbx_dica
			// 
			this.txtbx_dica.Location = new System.Drawing.Point(287, 311);
			this.txtbx_dica.Margin = new System.Windows.Forms.Padding(2);
			this.txtbx_dica.Multiline = true;
			this.txtbx_dica.Name = "txtbx_dica";
			this.txtbx_dica.Size = new System.Drawing.Size(586, 45);
			this.txtbx_dica.TabIndex = 15;
			// 
			// lbl_conselho
			// 
			this.lbl_conselho.Location = new System.Drawing.Point(105, 314);
			this.lbl_conselho.Name = "lbl_conselho";
			this.lbl_conselho.Size = new System.Drawing.Size(83, 44);
			this.lbl_conselho.TabIndex = 17;
			this.lbl_conselho.Text = "(para caso esqueça sua senha)";
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.SteelBlue;
			this.panel1.Location = new System.Drawing.Point(-41, 1);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(1133, 116);
			this.panel1.TabIndex = 18;
			// 
			// Cadastro
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.LightSteelBlue;
			this.ClientSize = new System.Drawing.Size(1084, 611);
			this.Controls.Add(this.lbl_conselho);
			this.Controls.Add(this.lbl_dica);
			this.Controls.Add(this.txtbx_dica);
			this.Controls.Add(this.lbl_titulo2);
			this.Controls.Add(this.lbl_serie);
			this.Controls.Add(this.lbl_senha);
			this.Controls.Add(this.lbl_usuario2);
			this.Controls.Add(this.btn_login);
			this.Controls.Add(this.btn_criarconta);
			this.Controls.Add(this.txtbx_senha);
			this.Controls.Add(this.txtbx_usuario);
			this.Controls.Add(this.cbx_serie);
			this.Controls.Add(this.panel1);
			this.Margin = new System.Windows.Forms.Padding(2);
			this.Name = "Cadastro";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Cadastro";
			this.Load += new System.EventHandler(this.CadastroLoad);
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label lbl_conselho;
		private System.Windows.Forms.TextBox txtbx_dica;
		private System.Windows.Forms.Label lbl_dica;
		private System.Windows.Forms.Label lbl_titulo2;
		private System.Windows.Forms.Label lbl_serie;
		private System.Windows.Forms.Button btn_login;
		private System.Windows.Forms.Button btn_criarconta;
		private System.Windows.Forms.Label lbl_usuario2;
		private System.Windows.Forms.Label lbl_senha;
		private System.Windows.Forms.TextBox txtbx_usuario;
		private System.Windows.Forms.TextBox txtbx_senha;
		private System.Windows.Forms.ComboBox cbx_serie;
	}
}
