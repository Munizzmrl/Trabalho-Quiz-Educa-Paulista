﻿/*
 * Created by SharpDevelop.
 * User: muril
 * Date: 10/10/2025
 * Time: 19:53
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Menu_principal
{
	/// <summary>
	/// Description of Humanas.
	/// </summary>
	public partial class Humanas : Form
	{
		public Humanas()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Btn_jogarClick(object sender, EventArgs e)
		{
		Qhumanas telaQhumanas = new Qhumanas();
					telaQhumanas.Show();
					this.Hide();	
		}
		
		void Btn_inicioClick(object sender, EventArgs e)
		{
		MainForm telaMainForm = new MainForm();
					telaMainForm.Show();
					this.Hide();	
		}
	}
}
