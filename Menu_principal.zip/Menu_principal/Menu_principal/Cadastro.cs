﻿/*
 * Created by SharpDevelop.
 * User: Aluno
 * Date: 06/10/2025
 * Time: 14:42
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;


namespace Menu_principal
{
	/// <summary>
	/// Description of Cadastro.
	/// </summary>
	public partial class Cadastro : Form
	{
		public Cadastro()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void ComboBox1SelectedIndexChanged(object sender, EventArgs e)
		{
			
		}
		
		void Btn_loginClick(object sender, EventArgs e)
		{
			Login telaLogin = new Login();
			telaLogin.Show();
			this.Hide();			
		}
		string arquivo = "usuarios.txt";
		void Btn_criarcontaClick(object sender, EventArgs e)
		{
			string usuario = txtbx_usuario.Text.Trim();
			string senha = txtbx_senha.Text.Trim();
			string serie = cbx_serie.Text.Trim();
			string dica = txtbx_dica.Text.Trim();
			if (usuario == "" || senha == "" || serie == ""){
				MessageBox.Show("Preencha os campos indicados.");
			} else {
				bool cadastrado = false;
				if (File.Exists(arquivo)){
					foreach(string linha in File.ReadAllLines(arquivo)){
						string[] dados = linha.Split (';');
						if (dados[0] == usuario){
							MessageBox.Show("Usuário já cadstrado.");
							cadastrado = true;
						}
					}
				}
				if (cadastrado == false){
					using (StreamWriter sw = File.AppendText(arquivo)){
						sw.WriteLine(usuario + ";" + senha + ";" + serie + ";" + dica);
						
					}
					MessageBox.Show("Usuário Cadastrado com sucesso!");
				}
			}
			txtbx_senha.Clear();
			txtbx_usuario.Clear();
			txtbx_dica.Clear();
		}
		
		
		void CadastroLoad(object sender, EventArgs e)
		{
			
		}
		
		void Label1Click(object sender, EventArgs e)
		{
			
		}
	}
}
