﻿/*
 * Created by SharpDevelop.
 * User: muril
 * Date: 28/10/2025
 * Time: 20:42
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Menu_principal
{
	partial class Placar
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.lbl_titulo = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.btnVoltar = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			this.SuspendLayout();
			// 
			// dataGridView1
			// 
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Location = new System.Drawing.Point(0, 134);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.Size = new System.Drawing.Size(709, 258);
			this.dataGridView1.TabIndex = 0;
			// 
			// lbl_titulo
			// 
			this.lbl_titulo.BackColor = System.Drawing.Color.SteelBlue;
			this.lbl_titulo.Font = new System.Drawing.Font("Cooper Black", 50.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_titulo.Location = new System.Drawing.Point(0, -2);
			this.lbl_titulo.Name = "lbl_titulo";
			this.lbl_titulo.Size = new System.Drawing.Size(712, 133);
			this.lbl_titulo.TabIndex = 14;
			this.lbl_titulo.Text = "Placar!";
			this.lbl_titulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.SteelBlue;
			this.panel1.Location = new System.Drawing.Point(0, -2);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(712, 118);
			this.panel1.TabIndex = 15;
			// 
			// btnVoltar
			// 
			this.btnVoltar.BackColor = System.Drawing.Color.SteelBlue;
			this.btnVoltar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnVoltar.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnVoltar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
			this.btnVoltar.Location = new System.Drawing.Point(610, 437);
			this.btnVoltar.Name = "btnVoltar";
			this.btnVoltar.Size = new System.Drawing.Size(99, 37);
			this.btnVoltar.TabIndex = 16;
			this.btnVoltar.Text = "Voltar!";
			this.btnVoltar.UseVisualStyleBackColor = false;
			this.btnVoltar.Click += new System.EventHandler(this.BtnVoltarClick);
			// 
			// Placar
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.LightSteelBlue;
			this.ClientSize = new System.Drawing.Size(709, 476);
			this.Controls.Add(this.btnVoltar);
			this.Controls.Add(this.lbl_titulo);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.dataGridView1);
			this.Name = "Placar";
			this.Text = "Placar";
			this.Load += new System.EventHandler(this.PlacarLoad);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Button btnVoltar;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label lbl_titulo;
		private System.Windows.Forms.DataGridView dataGridView1;
	}
}
