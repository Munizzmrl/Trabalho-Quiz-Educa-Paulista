﻿/*
 * Created by SharpDevelop.
 * User: muril
 * Date: 17/10/2025
 * Time: 18:27
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Menu_principal
{
	/// <summary>
	/// Description of Qmatematica.
	/// </summary>
	public partial class Qmatematica : Form
	{
		public Qmatematica()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Label1Click(object sender, EventArgs e)
		{
			
		}
		
		void Lbl_respo3Click(object sender, EventArgs e)
		{
			
		}
		
		void Panel1Paint(object sender, PaintEventArgs e)
		{
			
		}
		//variáveis gobais
		string alternativaCorreta = "x"; 
		int pontos = 0;
		int vidas = 3;
		int pergunta = 0;
			
			void Trocaralternativa() {
			panel1.Enabled = false;
			switch (pergunta) {
				case 1:
					btnPergunta1.Enabled = false;
					btnPergunta2.Enabled = true;
					break;
			case 2:
					btnPergunta2.Enabled = false;
					btnPergunta3.Enabled = true;
					break;
			case 3:
					btnPergunta3.Enabled = false;
					btnPergunta4.Enabled = true;
					break;
			case 4:
					btnPergunta4.Enabled = false;
					btnPergunta5.Enabled = true;
					break;
			case 5:
					btnPergunta5.Enabled = false;
					btnPergunta6.Enabled = true;
					break;
			case 6:
					btnPergunta6.Enabled = false;
					btnPergunta7.Enabled = true;
					break;
			case 7:
					btnPergunta7.Enabled = false;
					btnFinalizar.Enabled = true;	
					break;
			}
		}
			
			void Btn_aClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "A"){
				MessageBox.Show ("Parabéns! Você acertou. ");
				pontos++;
				lblPontos.Text = "Pontos: " + pontos;
				
			} else { 
					MessageBox.Show ("Você errou. ");
				vidas = vidas - 1;
				if (vidas == 2) {
					pictureBox3.Visible = false;
					
				} else if(vidas == 1){
					pictureBox2.Visible = false;
				}  else {
					pictureBox1.Visible = false;
					
			Derrota telaDerrota = new Derrota();
			telaDerrota.Show();
			this.Hide();
					
		}
				}
				Trocaralternativa();
			}
		
		void Btn_bClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "B"){
				MessageBox.Show ("Parabéns! Você acertou. ");
				pontos++;
				lblPontos.Text = "Pontos: " + pontos;
				
			} else { 
					MessageBox.Show ("Você errou. ");
				vidas = vidas - 1;
				if (vidas == 2) {
					pictureBox3.Visible = false;
					
				} else if(vidas == 1){
					pictureBox2.Visible = false;
				}  else {
					pictureBox1.Visible = false;
					
			Derrota telaDerrota = new Derrota();
			telaDerrota.Show();
			this.Hide();
					
		}
				}	
			Trocaralternativa();
		}
		
		void Btn_cClick(object sender, EventArgs e)
		{
		if (alternativaCorreta == "C"){
				MessageBox.Show ("Parabéns! Você acertou. ");
				pontos++;
				lblPontos.Text = "Pontos: " + pontos;
				
			} else { 
					MessageBox.Show ("Você errou. ");
				vidas = vidas - 1;
				if (vidas == 2) {
					pictureBox3.Visible = false;
					
				} else if(vidas == 1){
					pictureBox2.Visible = false;
				}  else {
					pictureBox1.Visible = false;
					
			Derrota telaDerrota = new Derrota();
			telaDerrota.Show();
			this.Hide();
					
		}
				}		
Trocaralternativa();			
		}
		
		void Btn_dClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "D"){
				MessageBox.Show ("Parabéns! Você acertou. ");
				pontos+=2;
				lblPontos.Text = "Pontos: " + pontos;
				
			} else { 
					MessageBox.Show ("Você errou. ");
				vidas = vidas - 1;
				if (vidas == 2) {
					pictureBox3.Visible = false;
					
				} else if(vidas == 1){
					pictureBox2.Visible = false;
				}  else {
					pictureBox1.Visible = false;
					
			Derrota telaDerrota = new Derrota();
			telaDerrota.Show();
			this.Hide();
					
		}
				}		
Trocaralternativa();			
		}
		
	
		
		void Btn_1Click(object sender, EventArgs e)
		{
			lblPergunta.Text = "Se x + 5 = 13, então x = ? ";
			
			lblTextoA.Text = "5";
			lblTextoB.Text = "7";
			lblTextoC.Text = "8";
			lblTextoD.Text = "18";
			alternativaCorreta = "C";	

			panel1.Enabled = true;
			btnPergunta1.Enabled = false;	
		
			pergunta = 1;			
		}
		
		void Btn_2Click(object sender, EventArgs e)
		{
				lblPergunta.Text = "Qual é o resultado de 45 ÷ 5? ";
			lblTextoA.Text = "5";
			lblTextoB.Text = "8";
			lblTextoC.Text = "9";
			lblTextoD.Text = "10";
			alternativaCorreta = "C";	

			panel1.Enabled = true;
			btnPergunta2.Enabled = false;	
				
			pergunta = 2;
		}
		
		void Btn_3Click(object sender, EventArgs e)
		{
				lblPergunta.Text = "Um quadrado possui lado medindo 4 cm. Qual é sua área? ";
			lblTextoA.Text = "16 cm²";
			lblTextoB.Text = "12 cm²";
			lblTextoC.Text = "8 cm²";
			lblTextoD.Text = "4 cm²";
			alternativaCorreta = "A";	

			panel1.Enabled = true;
			btnPergunta3.Enabled = false;	
			
			pergunta = 3;			
		}
		
		void Btn_4Click(object sender, EventArgs e)
		{
				lblPergunta.Text = "Quanto é 30% de 200? ";
			lblTextoA.Text = "50";
			lblTextoB.Text = "80";
			lblTextoC.Text = "70";
			lblTextoD.Text = "60";
			alternativaCorreta = "D";	

			panel1.Enabled = true;
			btnPergunta4.Enabled = false;	
		
			
			pergunta = 4;			
		}
		
		void Btn_5Click(object sender, EventArgs e)
		{
				lblPergunta.Text = "Qual expressão representa o dobro de um número n? ";
			lblTextoA.Text = "n + 2";
			lblTextoB.Text = "2n";
			lblTextoC.Text = "n - 2";
			lblTextoD.Text = "n²";
			alternativaCorreta = "B";	

			panel1.Enabled = true;
			btnPergunta5.Enabled = false;	
			
			pergunta = 5;			
		}
		
		void Btn_6Click(object sender, EventArgs e)
		{
				lblPergunta.Text = "Na lista de números: 2, 3, 5, 5, 8, qual é a moda? ";
			lblTextoA.Text = "2";
			lblTextoB.Text = "3";
			lblTextoC.Text = "5";
			lblTextoD.Text = "8";
			alternativaCorreta = "C";	

			panel1.Enabled = true;
			btnPergunta6.Enabled = false;	
			
			pergunta = 6;			
		
		}
		
		void Btn_7Click(object sender, EventArgs e)
		{
				lblPergunta.Text = "Qual figura possui três lados? ";
			lblTextoA.Text = "Quadrado";
			lblTextoB.Text = "Triângulo";
			lblTextoC.Text = "Retângulo";
			lblTextoD.Text = "Círculo";
			alternativaCorreta = "B";	

			panel1.Enabled = true;
			btnPergunta7.Enabled = false;	
					
			pergunta = 7;
		}
		
		void Btn_FinalizarClick(object sender, EventArgs e)
		{
		
		}
		
		void Label2Click(object sender, EventArgs e)
		{
			
		}
		
		void PictureBox2Click(object sender, EventArgs e)
		{
			
		}
		
		void Button1Click(object sender, EventArgs e)
		{
		if(pontos >=3){
							Vitoria telaVitoria = new Vitoria(pontos);
							telaVitoria.Show();
							this.Hide();

			} else {
				Derrota telaDerrota = new Derrota();
				telaDerrota.Show();
				this.Hide();
			}
		}
	}
}
