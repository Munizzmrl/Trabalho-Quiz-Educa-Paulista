﻿/*
 * Created by SharpDevelop.
 * User: muril
 * Date: 10/10/2025
 * Time: 20:09
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;

namespace Menu_principal
{
	/// <summary>
	/// Description of DailyStreak.
	/// </summary>
public class DailyStreak
{
    private static string filePath = "streak.txt";
    public static int StreakCount = 0;
    public static DateTime LastLoginDate = DateTime.MinValue;

    public static void LoadStreak()
    {
        if (File.Exists(filePath))
        {
            string[] lines = File.ReadAllLines(filePath);
            if (lines.Length >= 2)
            {
                int.TryParse(lines[0], out StreakCount);
                DateTime.TryParse(lines[1], out LastLoginDate);
            }
        }
    }

    public static void UpdateStreak()
    {
        DateTime today = DateTime.Today;

        if (LastLoginDate == DateTime.MinValue)
        {
            StreakCount = 1; // primeira vez
        }
        else if ((today - LastLoginDate).Days == 1)
        {
            StreakCount++; // manteve o streak
        }
        else if ((today - LastLoginDate).Days > 1)
        {
            StreakCount = 1; // perdeu o streak
        }

        LastLoginDate = today;

        File.WriteAllLines(filePath, new string[]
        {
            StreakCount.ToString(),
            LastLoginDate.ToString("yyyy-MM-dd")
        });
    }
}
}