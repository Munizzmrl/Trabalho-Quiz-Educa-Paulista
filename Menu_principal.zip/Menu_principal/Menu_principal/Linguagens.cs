﻿/*
 * Created by SharpDevelop.
 * User: muril
 * Date: 10/10/2025
 * Time: 20:36
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Menu_principal
{
	/// <summary>
	/// Description of Linguagens.
	/// </summary>
	public partial class Linguagens : Form
	{
		public Linguagens()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Btn_jogarClick(object sender, EventArgs e)
		{
		Qlinguagens telaQlinguagens = new Qlinguagens();
					telaQlinguagens.Show();
					this.Hide();
		}
		
		void Btn_inicioClick(object sender, EventArgs e)
		{
		MainForm telaMainForm = new MainForm();
					telaMainForm.Show();
					this.Hide();	
		}
	}
}
