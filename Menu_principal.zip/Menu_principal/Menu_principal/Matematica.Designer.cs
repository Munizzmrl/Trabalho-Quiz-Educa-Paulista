﻿/*
 * Created by SharpDevelop.
 * User: muril
 * Date: 10/10/2025
 * Time: 20:36
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Menu_principal
{
	partial class Matematica
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.lbl_titulo = new System.Windows.Forms.Label();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.btn_jogar = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.btn_inicio = new System.Windows.Forms.Button();
			this.groupBox2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// lbl_titulo
			// 
			this.lbl_titulo.BackColor = System.Drawing.Color.SteelBlue;
			this.lbl_titulo.Font = new System.Drawing.Font("Cooper Black", 50.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_titulo.Location = new System.Drawing.Point(-2, -2);
			this.lbl_titulo.Name = "lbl_titulo";
			this.lbl_titulo.Size = new System.Drawing.Size(712, 135);
			this.lbl_titulo.TabIndex = 10;
			this.lbl_titulo.Text = "Matemática";
			this.lbl_titulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// groupBox2
			// 
			this.groupBox2.BackColor = System.Drawing.SystemColors.Menu;
			this.groupBox2.Controls.Add(this.btn_jogar);
			this.groupBox2.Controls.Add(this.label3);
			this.groupBox2.Location = new System.Drawing.Point(428, 123);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(269, 248);
			this.groupBox2.TabIndex = 14;
			this.groupBox2.TabStop = false;
			// 
			// btn_jogar
			// 
			this.btn_jogar.BackColor = System.Drawing.Color.SteelBlue;
			this.btn_jogar.Font = new System.Drawing.Font("Trebuchet MS", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btn_jogar.ForeColor = System.Drawing.Color.Aquamarine;
			this.btn_jogar.Location = new System.Drawing.Point(34, 90);
			this.btn_jogar.Name = "btn_jogar";
			this.btn_jogar.Size = new System.Drawing.Size(200, 92);
			this.btn_jogar.TabIndex = 1;
			this.btn_jogar.Text = "jogar!";
			this.btn_jogar.UseVisualStyleBackColor = false;
			this.btn_jogar.Click += new System.EventHandler(this.Btn_jogarClick);
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.Location = new System.Drawing.Point(0, 8);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(269, 79);
			this.label3.TabIndex = 0;
			this.label3.Text = "Hora do Quiz!\r\nPronto para começar?";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// groupBox1
			// 
			this.groupBox1.BackColor = System.Drawing.SystemColors.Menu;
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Location = new System.Drawing.Point(12, 123);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(256, 170);
			this.groupBox1.TabIndex = 13;
			this.groupBox1.TabStop = false;
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(0, 80);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(256, 81);
			this.label2.TabIndex = 1;
			this.label2.Text = "Aritimética\r\nÁlgebra\r\nGeometria\r\nEstatística\r\n";
			this.label2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Trebuchet MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(0, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(256, 72);
			this.label1.TabIndex = 0;
			this.label1.Text = "Matérias Contidas na área:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btn_inicio
			// 
			this.btn_inicio.BackColor = System.Drawing.Color.CornflowerBlue;
			this.btn_inicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_inicio.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btn_inicio.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.btn_inicio.Location = new System.Drawing.Point(12, 429);
			this.btn_inicio.Name = "btn_inicio";
			this.btn_inicio.Size = new System.Drawing.Size(110, 35);
			this.btn_inicio.TabIndex = 16;
			this.btn_inicio.Text = "Voltar ao início";
			this.btn_inicio.UseVisualStyleBackColor = false;
			this.btn_inicio.Click += new System.EventHandler(this.Btn_inicioClick);
			// 
			// Matematica
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.LightSteelBlue;
			this.ClientSize = new System.Drawing.Size(709, 476);
			this.Controls.Add(this.btn_inicio);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.lbl_titulo);
			this.Name = "Matematica";
			this.Text = "Matematica";
			this.groupBox2.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Button btn_inicio;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button btn_jogar;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Label lbl_titulo;
	}
}
