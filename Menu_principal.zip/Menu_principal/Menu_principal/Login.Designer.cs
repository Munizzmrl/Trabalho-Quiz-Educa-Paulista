﻿/*
 * Created by SharpDevelop.
 * User: Aluno
 * Date: 06/10/2025
 * Time: 13:48
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Menu_principal
{
	partial class Login
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
			this.lbl_usuario = new System.Windows.Forms.Label();
			this.lbl_senha = new System.Windows.Forms.Label();
			this.txtbx_usuario = new System.Windows.Forms.TextBox();
			this.txtbx_senha = new System.Windows.Forms.TextBox();
			this.btn_cadastrar = new System.Windows.Forms.Button();
			this.btn_entrar = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.lbl_titulo = new System.Windows.Forms.Label();
			this.linkLabel1 = new System.Windows.Forms.LinkLabel();
			this.panel1 = new System.Windows.Forms.Panel();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// lbl_usuario
			// 
			this.lbl_usuario.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_usuario.Location = new System.Drawing.Point(266, 231);
			this.lbl_usuario.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lbl_usuario.Name = "lbl_usuario";
			this.lbl_usuario.Size = new System.Drawing.Size(124, 49);
			this.lbl_usuario.TabIndex = 0;
			this.lbl_usuario.Text = "Usuário:";
			// 
			// lbl_senha
			// 
			this.lbl_senha.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_senha.Location = new System.Drawing.Point(289, 295);
			this.lbl_senha.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lbl_senha.Name = "lbl_senha";
			this.lbl_senha.Size = new System.Drawing.Size(101, 31);
			this.lbl_senha.TabIndex = 1;
			this.lbl_senha.Text = "Senha:";
			this.lbl_senha.Click += new System.EventHandler(this.Lbl_senhaClick);
			// 
			// txtbx_usuario
			// 
			this.txtbx_usuario.Location = new System.Drawing.Point(395, 231);
			this.txtbx_usuario.Margin = new System.Windows.Forms.Padding(2);
			this.txtbx_usuario.Multiline = true;
			this.txtbx_usuario.Name = "txtbx_usuario";
			this.txtbx_usuario.Size = new System.Drawing.Size(289, 30);
			this.txtbx_usuario.TabIndex = 2;
			// 
			// txtbx_senha
			// 
			this.txtbx_senha.Location = new System.Drawing.Point(395, 296);
			this.txtbx_senha.Margin = new System.Windows.Forms.Padding(2);
			this.txtbx_senha.Multiline = true;
			this.txtbx_senha.Name = "txtbx_senha";
			this.txtbx_senha.PasswordChar = '#';
			this.txtbx_senha.Size = new System.Drawing.Size(289, 30);
			this.txtbx_senha.TabIndex = 3;
			// 
			// btn_cadastrar
			// 
			this.btn_cadastrar.BackColor = System.Drawing.SystemColors.ControlLightLight;
			this.btn_cadastrar.Font = new System.Drawing.Font("Trebuchet MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btn_cadastrar.Location = new System.Drawing.Point(313, 391);
			this.btn_cadastrar.Margin = new System.Windows.Forms.Padding(2);
			this.btn_cadastrar.Name = "btn_cadastrar";
			this.btn_cadastrar.Size = new System.Drawing.Size(109, 62);
			this.btn_cadastrar.TabIndex = 4;
			this.btn_cadastrar.Text = "Cadastrar";
			this.btn_cadastrar.UseVisualStyleBackColor = false;
			this.btn_cadastrar.Click += new System.EventHandler(this.Btn_cadastrarClick);
			// 
			// btn_entrar
			// 
			this.btn_entrar.BackColor = System.Drawing.SystemColors.ControlLightLight;
			this.btn_entrar.Font = new System.Drawing.Font("Trebuchet MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btn_entrar.Location = new System.Drawing.Point(559, 391);
			this.btn_entrar.Margin = new System.Windows.Forms.Padding(2);
			this.btn_entrar.Name = "btn_entrar";
			this.btn_entrar.Size = new System.Drawing.Size(107, 62);
			this.btn_entrar.TabIndex = 5;
			this.btn_entrar.Text = "Entrar";
			this.btn_entrar.UseVisualStyleBackColor = false;
			this.btn_entrar.Click += new System.EventHandler(this.Btn_entrarClick);
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackColor = System.Drawing.Color.SteelBlue;
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(-98, -21);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(413, 236);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 6;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.Click += new System.EventHandler(this.PictureBox1Click);
			// 
			// lbl_titulo
			// 
			this.lbl_titulo.BackColor = System.Drawing.Color.SteelBlue;
			this.lbl_titulo.Font = new System.Drawing.Font("Cooper Black", 62.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_titulo.Location = new System.Drawing.Point(215, 48);
			this.lbl_titulo.Name = "lbl_titulo";
			this.lbl_titulo.Size = new System.Drawing.Size(740, 167);
			this.lbl_titulo.TabIndex = 7;
			this.lbl_titulo.Text = "Seja Bem Vindo!";
			this.lbl_titulo.Click += new System.EventHandler(this.Lbl_tituloClick);
			// 
			// linkLabel1
			// 
			this.linkLabel1.Location = new System.Drawing.Point(564, 328);
			this.linkLabel1.Name = "linkLabel1";
			this.linkLabel1.Size = new System.Drawing.Size(120, 23);
			this.linkLabel1.TabIndex = 8;
			this.linkLabel1.TabStop = true;
			this.linkLabel1.Text = "Esqueceu sua senha?";
			this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel1LinkClicked);
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.SteelBlue;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(955, 192);
			this.panel1.TabIndex = 9;
			// 
			// Login
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.LightSteelBlue;
			this.ClientSize = new System.Drawing.Size(956, 525);
			this.Controls.Add(this.linkLabel1);
			this.Controls.Add(this.lbl_titulo);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.btn_entrar);
			this.Controls.Add(this.btn_cadastrar);
			this.Controls.Add(this.txtbx_senha);
			this.Controls.Add(this.txtbx_usuario);
			this.Controls.Add(this.lbl_senha);
			this.Controls.Add(this.lbl_usuario);
			this.Controls.Add(this.panel1);
			this.Margin = new System.Windows.Forms.Padding(2);
			this.Name = "Login";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Login";
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.LinkLabel linkLabel1;
		private System.Windows.Forms.Label lbl_titulo;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Button btn_entrar;
		private System.Windows.Forms.Button btn_cadastrar;
		private System.Windows.Forms.TextBox txtbx_senha;
		private System.Windows.Forms.TextBox txtbx_usuario;
		private System.Windows.Forms.Label lbl_senha;
		private System.Windows.Forms.Label lbl_usuario;
	}
}
