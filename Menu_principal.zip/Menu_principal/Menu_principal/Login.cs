﻿/*
 * Created by SharpDevelop.
 * User: Aluno
 * Date: 06/10/2025
 * Time: 13:48
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
namespace Menu_principal
{
	/// <summary>
	/// Description of Login.
	/// </summary>
	public partial class Login : Form
	{
		public Login()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Lbl_senhaClick(object sender, EventArgs e)
		{
			
		}
		string arquivo = "usuarios.txt";
		void Btn_entrarClick(object sender, EventArgs e)
		{
				string usuario = txtbx_usuario.Text.Trim();
			string senha = txtbx_senha.Text.Trim();
			
			if(!File.Exists(arquivo)){
				MessageBox.Show("Nenhum usuário Cadastrado.");
				
			}
			bool encontrado = false;
			foreach (string linha in File.ReadAllLines(arquivo)){
				string[] dados = linha.Split(';');
				if (dados[0] == usuario && dados[1] == senha){
					MessageBox.Show("Usuário encontrado.");
					MessageBox.Show("Seja bem-vindo(a), " + usuario);
					encontrado = true;
					MainForm telaMainForm = new MainForm();
					telaMainForm.Show();
					this.Hide();
				}
			}
			
			if (encontrado == false) {
				MessageBox.Show("Usuário ou senha incorretos.");
			}
		}
		
		void Btn_cadastrarClick(object sender, EventArgs e)
		{
				Cadastro telaCadastro = new Cadastro();
				telaCadastro.Show();
				this.Hide();
		}
		
		void PictureBox1Click(object sender, EventArgs e)
		{
			
		}
		
		void LinkLabel1LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
    string usuario = txtbx_usuario.Text.Trim(); // pega o usuário digitado
    if (usuario == ""){
        MessageBox.Show("Digite seu nome de usuário primeiro.");
        return;
    }

    if (!File.Exists(arquivo)){
        MessageBox.Show("Nenhum usuário cadastrado.");
        return;
    }

    bool encontrado = false;
    foreach (string linha in File.ReadAllLines(arquivo)){
        string[] dados = linha.Split(';');
        if (dados[0] == usuario){
            string dica = dados[3]; // pega a dica
            MessageBox.Show("Dica de senha: " + dica);
            encontrado = true;
            break;
        }
    }

    if (!encontrado){
        MessageBox.Show("Usuário não encontrado.");
    }
}
		
		void Lbl_tituloClick(object sender, EventArgs e)
		{
			
		}
	}
}
