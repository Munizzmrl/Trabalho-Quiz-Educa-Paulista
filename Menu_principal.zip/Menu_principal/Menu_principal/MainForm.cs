﻿/*
 * Created by SharpDevelop.
 * User: Aluno
 * Date: 06/10/2025
 * Time: 13:12
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Menu_principal
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void SairToolStripMenuItemClick(object sender, EventArgs e)
		{
			Application.Exit();
		}
		
		void Button1Click(object sender, EventArgs e)
		{
			Placar telaPlacar = new Placar();
				telaPlacar.Show();
				this.Hide();
		}
		
		void Gpbx_placarEnter(object sender, EventArgs e)
		{
			
		}
		
		private void MainFormLoad(object sender, EventArgs e)
{
    DailyStreak.LoadStreak();
    DailyStreak.UpdateStreak();

    lbl_streak.Text = " Streak atual: " + DailyStreak.StreakCount + " dia(s) 🔥";
}
		
		void Btn_humanasClick(object sender, EventArgs e)
		{
			Humanas telaHumanas = new Humanas();
				telaHumanas.Show();
				this.Hide();
		}
		
		void Btn_naturezaClick(object sender, EventArgs e)
		{
			Natureza telaNatureza = new Natureza();
				telaNatureza.Show();
				this.Hide();
		}
		
		void Btn_matematicaClick(object sender, EventArgs e)
		{
			Matematica telaMatematica = new Matematica();
				telaMatematica.Show();
				this.Hide();
		}
		
		void Btn_linguagensClick(object sender, EventArgs e)
		{
			Linguagens telaLinguagens = new Linguagens();
				telaLinguagens.Show();
				this.Hide();
		}
		
		void Btn_sairClick(object sender, EventArgs e)
		{
			Application.Exit();
		}
	}
}
