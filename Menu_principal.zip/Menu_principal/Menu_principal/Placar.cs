﻿/*
 * Created by SharpDevelop.
 * User: muril
 * Date: 28/10/2025
 * Time: 20:42
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace Menu_principal
{
    /// <summary>
    /// Classe responsável por exibir o placar de pontuações.
    /// </summary>
    public partial class Placar : Form
    {
        public Placar()
        {
            //
            // Suporte necessário ao designer do Windows Forms.
            //
            InitializeComponent();

            //
            // Código a ser executado após a inicialização.
            //
        }

        void PlacarLoad(object sender, EventArgs e)
        {
            try
            {
                // Caminho do arquivo de pontuações (pode ajustar se necessário)
                string caminhoArquivo = "pontuacoes.txt";

                // Verifica se o arquivo existe
                if (!File.Exists(caminhoArquivo))
                {
                    MessageBox.Show("Arquivo 'pontuacoes.txt' não encontrado!");
                    return;
                }

                // Lê todas as linhas do arquivo
                string[] linhas = File.ReadAllLines(caminhoArquivo);
                int qtd = linhas.Length;

                string[] nomes = new string[qtd];
                int[] pontos = new int[qtd];
                int contador = 0;

                // Processa cada linha
                foreach (string linha in linhas)
                {
                    string[] partes = linha.Split(',');

                    if (partes.Length == 2)
                    {
                        string nome = partes[0].Trim();
                        int valor;

                        if (int.TryParse(partes[1].Trim(), out valor))
                        {
                            nomes[contador] = nome;
                            pontos[contador] = valor;
                            contador++;
                        }
                    }
                }

                // Ordena por pontuação decrescente
                for (int i = 0; i < contador - 1; i++)
                {
                    for (int j = i + 1; j < contador; j++)
                    {
                        if (pontos[j] > pontos[i])
                        {
                            int tempPontos = pontos[i];
                            pontos[i] = pontos[j];
                            pontos[j] = tempPontos;

                            string tempNome = nomes[i];
                            nomes[i] = nomes[j];
                            nomes[j] = tempNome;
                        }
                    }
                }

                // Configura o DataGridView
                dataGridView1.Columns.Clear();
                dataGridView1.Rows.Clear();
                dataGridView1.ReadOnly = true;
                dataGridView1.AllowUserToAddRows = false;
                dataGridView1.RowHeadersVisible = false;
                dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                // Cria colunas
                dataGridView1.Columns.Add("Posicao", "Posição");
                dataGridView1.Columns.Add("Nome", "Nome");
                dataGridView1.Columns.Add("Pontos", "Pontos");

                // Adiciona dados
                for (int i = 0; i < contador; i++)
                {
                    dataGridView1.Rows.Add((i + 1).ToString() + "º", nomes[i], pontos[i]);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar o arquivo: " + ex.Message);
            }
        }
		
		void BtnVoltarClick(object sender, EventArgs e)
		{
		MainForm telaMainForm = new MainForm();
					telaMainForm.Show();
					this.Hide();	
		}
    }
}
