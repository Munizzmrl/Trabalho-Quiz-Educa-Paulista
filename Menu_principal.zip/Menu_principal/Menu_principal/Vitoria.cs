﻿/*
 * Created by SharpDevelop.
 * User: muril
 * Date: 01/11/2025
 * Time: 20:13
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Menu_principal
{
	/// <summary>
	/// Description of Vitoria.
	/// </summary>
	public partial class Vitoria : Form
{
  
	int pontosRecebidos;
	
    public Vitoria(int pontos)
    {
        InitializeComponent();
        pontosRecebidos = pontos;
         lblPontos.Text = pontos.ToString();
         btnSalvar.Click += btnSalvar_Click;
    }

   private void Vitoria_Load(object sender, EventArgs e)
{
    lblPontos.Text = "Sua pontuação: " + pontosRecebidos;
}

		
private void btnSalvar_Click(object sender, EventArgs e)
{
    string nome = txtNome.Text;
    int pontos = pontosRecebidos; // substitua pela sua variável real

    RegistroPontuacao.SalvarPontuacao(nome, pontos);

    if (nome == "")
    {
        MessageBox.Show("Digite um nome para registrar no placar!");
        return;
    }
    
    MessageBox.Show("Pontuação salva com sucesso!");

    Placar telaPlacar = new Placar();
    telaPlacar.Show();
    this.Hide();
}

 
		}
		
		
}
	
	


