﻿/*
 * Created by SharpDevelop.
 * User: muril
 * Date: 17/10/2025
 * Time: 18:27
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Menu_principal
{
	/// <summary>
	/// Description of Qmatematica.
	/// </summary>
	public partial class Qlinguagens : Form
	{
		public Qlinguagens()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Label1Click(object sender, EventArgs e)
		{
			
		}
		
		void Lbl_respo3Click(object sender, EventArgs e)
		{
			
		}
		
		void Panel1Paint(object sender, PaintEventArgs e)
		{
			
		}
		//variáveis gobais
		string alternativaCorreta = "x"; 
		int pontos = 0;
		int vidas = 3;
		int pergunta = 0;
			
			void Trocaralternativa() {
			panel1.Enabled = false;
			switch (pergunta) {
				case 1:
					btnPergunta1.Enabled = false;
					btnPergunta2.Enabled = true;
					break;
			case 2:
					btnPergunta2.Enabled = false;
					btnPergunta3.Enabled = true;
					break;
			case 3:
					btnPergunta3.Enabled = false;
					btnPergunta4.Enabled = true;
					break;
			case 4:
					btnPergunta4.Enabled = false;
					btnPergunta5.Enabled = true;
					break;
			case 5:
					btnPergunta5.Enabled = false;
					btnPergunta6.Enabled = true;
					break;
			case 6:
					btnPergunta6.Enabled = false;
					btnPergunta7.Enabled = true;
					break;
			case 7:
					btnPergunta7.Enabled = false;
					btnFinalizar.Enabled = true;	
					break;
			}
		}
			
			void Btn_aClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "A"){
				MessageBox.Show ("Parabéns! Você acertou. ");
				pontos++;
				lblPontos.Text = "Pontos: " + pontos;
				
			} else { 
					MessageBox.Show ("Você errou. ");
				vidas = vidas - 1;
				if (vidas == 2) {
					pictureBox3.Visible = false;
					
				} else if(vidas == 1){
					pictureBox2.Visible = false;
				}  else {
					pictureBox1.Visible = false;
					
			Derrota telaDerrota = new Derrota();
			telaDerrota.Show();
			this.Hide();
					
		}
				}
				Trocaralternativa();
			}
		
		void Btn_bClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "B"){
				MessageBox.Show ("Parabéns! Você acertou. ");
				pontos++;
				lblPontos.Text = "Pontos: " + pontos;
				
			} else { 
					MessageBox.Show ("Você errou. ");
				vidas = vidas - 1;
				if (vidas == 2) {
					pictureBox3.Visible = false;
					
				} else if(vidas == 1){
					pictureBox2.Visible = false;
				}  else {
					pictureBox1.Visible = false;
					
			Derrota telaDerrota = new Derrota();
			telaDerrota.Show();
			this.Hide();
					
		}
				}	
			Trocaralternativa();
		}
		
		void Btn_cClick(object sender, EventArgs e)
		{
		if (alternativaCorreta == "C"){
				MessageBox.Show ("Parabéns! Você acertou. ");
				pontos++;
				lblPontos.Text = "Pontos: " + pontos;
				
			} else { 
					MessageBox.Show ("Você errou. ");
				vidas = vidas - 1;
				if (vidas == 2) {
					pictureBox3.Visible = false;
					
				} else if(vidas == 1){
					pictureBox2.Visible = false;
				}  else {
					pictureBox1.Visible = false;
					
			Derrota telaDerrota = new Derrota();
			telaDerrota.Show();
			this.Hide();
					
		}
				}		
Trocaralternativa();			
		}
		
		void Btn_dClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "D"){
				MessageBox.Show ("Parabéns! Você acertou. ");
				pontos+=2;
				lblPontos.Text = "Pontos: " + pontos;
				
			} else { 
					MessageBox.Show ("Você errou. ");
				vidas = vidas - 1;
				if (vidas == 2) {
					pictureBox3.Visible = false;
					
				} else if(vidas == 1){
					pictureBox2.Visible = false;
				}  else {
					pictureBox1.Visible = false;
					
			Derrota telaDerrota = new Derrota();
			telaDerrota.Show();
			this.Hide();
					
		}
				}		
Trocaralternativa();			
		}
		
	
		
		void Btn_1Click(object sender, EventArgs e)
		{
			lblPergunta.Text = "Em qual opção há um substantivo? ";
			lblTextoA.Text = "Rápido";
			lblTextoB.Text = "Beleza";
			lblTextoC.Text = "Correr";
			lblTextoD.Text = "Feliz";
			alternativaCorreta = "B";	

			panel1.Enabled = true;
			btnPergunta1.Enabled = false;	
		
			pergunta = 1;			
		}
		
		void Btn_2Click(object sender, EventArgs e)
		{
				lblPergunta.Text = "Qual frase está escrita corretamente? ";
			lblTextoA.Text = "Nós foi ao cinema.";
			lblTextoB.Text = "Ela vai estudar amanhã.";
			lblTextoC.Text = "Eu gostam de música.";
			lblTextoD.Text = "Ele vão viajar.";
			alternativaCorreta = "B";	

			panel1.Enabled = true;
			btnPergunta2.Enabled = false;	
				
			pergunta = 2;
		}
		
		void Btn_3Click(object sender, EventArgs e)
		{
				lblPergunta.Text = "A palavra “felizmente” é classificada como: ";
			lblTextoA.Text = "Substantivo";
			lblTextoB.Text = "Adjetivo";
			lblTextoC.Text = "Advérbio";
			lblTextoD.Text = "Verbo";
			alternativaCorreta = "C";	

			panel1.Enabled = true;
			btnPergunta3.Enabled = false;	
			
			pergunta = 3;			
		}
		
		void Btn_4Click(object sender, EventArgs e)
		{
				lblPergunta.Text = "Qual é a tradução correta de (book)? ";
			lblTextoA.Text = "Caneta";
			lblTextoB.Text = "Caderno";
			lblTextoC.Text = "Mesa";
			lblTextoD.Text = "Livro";
			alternativaCorreta = "D";	

			panel1.Enabled = true;
			btnPergunta4.Enabled = false;	
		
			
			pergunta = 4;			
		}
		
		void Btn_5Click(object sender, EventArgs e)
		{
				lblPergunta.Text = "A frase “They are students” significa: ";
			lblTextoA.Text = "Eles são estudantes.";
			lblTextoB.Text = "Eles estão na escola.";
			lblTextoC.Text = "Eles eram estudantes.";
			lblTextoD.Text = "Eles estudam agora.";
			alternativaCorreta = "A";	

			panel1.Enabled = true;
			btnPergunta5.Enabled = false;	
			
			pergunta = 5;			
		}
		
		void Btn_6Click(object sender, EventArgs e)
		{
				lblPergunta.Text = "Qual alternativa completa corretamente: \nI ____ a dog. ";
			lblTextoA.Text = "has";
			lblTextoB.Text = "have";
			lblTextoC.Text = "haves";
			lblTextoD.Text = "having";
			alternativaCorreta = "B";	

			panel1.Enabled = true;
			btnPergunta6.Enabled = false;	
			
			pergunta = 6;			
		
		}
		
		void Btn_7Click(object sender, EventArgs e)
		{
				lblPergunta.Text = "O plural de child é: ";
			lblTextoA.Text = "childs";
			lblTextoB.Text = "children";
			lblTextoC.Text = "childes";
			lblTextoD.Text = "childrens";
			alternativaCorreta = "B";	

			panel1.Enabled = true;
			btnPergunta7.Enabled = false;	
					
			pergunta = 7;
		}
		
		void Btn_FinalizarClick(object sender, EventArgs e)
		{
		
		}
		
		void Label2Click(object sender, EventArgs e)
		{
			
		}
		
		void PictureBox2Click(object sender, EventArgs e)
		{
			
		}
		
		void Button1Click(object sender, EventArgs e)
		{
		if(pontos >=3){
							Vitoria telaVitoria = new Vitoria(pontos);
							telaVitoria.Show();
							this.Hide();

			} else {
				Derrota telaDerrota = new Derrota();
				telaDerrota.Show();
				this.Hide();
			}
		}
	}
}

