﻿/*
 * Created by SharpDevelop.
 * User: muril
 * Date: 01/11/2025
 * Time: 20:13
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Menu_principal
{
	/// <summary>
	/// Description of Derrota.
	/// </summary>
	public partial class Derrota : Form
	{
		public Derrota()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Label1Click(object sender, EventArgs e)
		{
			
		}
		
		void Button1Click(object sender, EventArgs e)
		{
		MainForm telaMainForm = new MainForm();
		telaMainForm.Show();
		this.Hide();	
		}
	}
}
