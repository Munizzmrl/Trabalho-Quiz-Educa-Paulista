﻿/*
 * Created by SharpDevelop.
 * User: muril
 * Date: 03/12/2025
 * Time: 19:17
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;
using System.Windows.Forms;

public static class RegistroPontuacao
{
    public static void SalvarPontuacao(string nome, int pontos)
    {
     

    	try
        {
            string caminhoArquivo = "pontuacoes.txt";
            string linha = nome + ";" + pontos;
        	File.AppendAllText("placar.txt", linha + "\n");

            if (!File.Exists(caminhoArquivo))
            {
                File.WriteAllText(caminhoArquivo, "");
            }

            using (StreamWriter sw = File.AppendText(caminhoArquivo))
            {
                sw.WriteLine("\n" + nome + ", " + pontos);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Erro ao salvar pontuação: " + ex.Message);
        }
    }
}


