﻿/*
 * Created by SharpDevelop.
 * User: muril
 * Date: 17/10/2025
 * Time: 18:27
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Menu_principal
{
	partial class Qmatematica
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Qmatematica));
			this.panel1 = new System.Windows.Forms.Panel();
			this.lblTextoD = new System.Windows.Forms.Label();
			this.lblTextoC = new System.Windows.Forms.Label();
			this.lblTextoB = new System.Windows.Forms.Label();
			this.lblTextoA = new System.Windows.Forms.Label();
			this.btnAlternativaD = new System.Windows.Forms.Button();
			this.btnAlternativaB = new System.Windows.Forms.Button();
			this.btnAlternativaC = new System.Windows.Forms.Button();
			this.btnAlternativaA = new System.Windows.Forms.Button();
			this.lblPergunta = new System.Windows.Forms.Label();
			this.btnPergunta1 = new System.Windows.Forms.Button();
			this.btnPergunta2 = new System.Windows.Forms.Button();
			this.btnPergunta3 = new System.Windows.Forms.Button();
			this.btnPergunta4 = new System.Windows.Forms.Button();
			this.btnPergunta5 = new System.Windows.Forms.Button();
			this.btnPergunta6 = new System.Windows.Forms.Button();
			this.btnPergunta7 = new System.Windows.Forms.Button();
			this.lblPontos = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.lbl_vidas = new System.Windows.Forms.Label();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.pictureBox3 = new System.Windows.Forms.PictureBox();
			this.btnFinalizar = new System.Windows.Forms.Button();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.lblTextoD);
			this.panel1.Controls.Add(this.lblTextoC);
			this.panel1.Controls.Add(this.lblTextoB);
			this.panel1.Controls.Add(this.lblTextoA);
			this.panel1.Controls.Add(this.btnAlternativaD);
			this.panel1.Controls.Add(this.btnAlternativaB);
			this.panel1.Controls.Add(this.btnAlternativaC);
			this.panel1.Controls.Add(this.btnAlternativaA);
			this.panel1.Controls.Add(this.lblPergunta);
			this.panel1.Enabled = false;
			this.panel1.Location = new System.Drawing.Point(12, 51);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(541, 335);
			this.panel1.TabIndex = 0;
			this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel1Paint);
			// 
			// lblTextoD
			// 
			this.lblTextoD.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTextoD.Location = new System.Drawing.Point(103, 266);
			this.lblTextoD.Name = "lblTextoD";
			this.lblTextoD.Size = new System.Drawing.Size(435, 30);
			this.lblTextoD.TabIndex = 8;
			this.lblTextoD.Text = "Resposta 4";
			// 
			// lblTextoC
			// 
			this.lblTextoC.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTextoC.Location = new System.Drawing.Point(103, 230);
			this.lblTextoC.Name = "lblTextoC";
			this.lblTextoC.Size = new System.Drawing.Size(435, 30);
			this.lblTextoC.TabIndex = 7;
			this.lblTextoC.Text = "Resposta 3";
			this.lblTextoC.Click += new System.EventHandler(this.Lbl_respo3Click);
			// 
			// lblTextoB
			// 
			this.lblTextoB.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTextoB.Location = new System.Drawing.Point(103, 194);
			this.lblTextoB.Name = "lblTextoB";
			this.lblTextoB.Size = new System.Drawing.Size(435, 30);
			this.lblTextoB.TabIndex = 6;
			this.lblTextoB.Text = "Resposta 2";
			// 
			// lblTextoA
			// 
			this.lblTextoA.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTextoA.Location = new System.Drawing.Point(103, 158);
			this.lblTextoA.Name = "lblTextoA";
			this.lblTextoA.Size = new System.Drawing.Size(435, 30);
			this.lblTextoA.TabIndex = 5;
			this.lblTextoA.Text = "Resposta 1";
			// 
			// btnAlternativaD
			// 
			this.btnAlternativaD.BackColor = System.Drawing.Color.White;
			this.btnAlternativaD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnAlternativaD.Location = new System.Drawing.Point(30, 266);
			this.btnAlternativaD.Name = "btnAlternativaD";
			this.btnAlternativaD.Size = new System.Drawing.Size(67, 30);
			this.btnAlternativaD.TabIndex = 3;
			this.btnAlternativaD.Text = "D";
			this.btnAlternativaD.UseVisualStyleBackColor = false;
			this.btnAlternativaD.Click += new System.EventHandler(this.Btn_dClick);
			// 
			// btnAlternativaB
			// 
			this.btnAlternativaB.BackColor = System.Drawing.Color.White;
			this.btnAlternativaB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnAlternativaB.Location = new System.Drawing.Point(30, 194);
			this.btnAlternativaB.Name = "btnAlternativaB";
			this.btnAlternativaB.Size = new System.Drawing.Size(67, 30);
			this.btnAlternativaB.TabIndex = 2;
			this.btnAlternativaB.Text = "B";
			this.btnAlternativaB.UseVisualStyleBackColor = false;
			this.btnAlternativaB.Click += new System.EventHandler(this.Btn_bClick);
			// 
			// btnAlternativaC
			// 
			this.btnAlternativaC.BackColor = System.Drawing.Color.White;
			this.btnAlternativaC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnAlternativaC.Location = new System.Drawing.Point(30, 230);
			this.btnAlternativaC.Name = "btnAlternativaC";
			this.btnAlternativaC.Size = new System.Drawing.Size(67, 30);
			this.btnAlternativaC.TabIndex = 2;
			this.btnAlternativaC.Text = "C";
			this.btnAlternativaC.UseVisualStyleBackColor = false;
			this.btnAlternativaC.Click += new System.EventHandler(this.Btn_cClick);
			// 
			// btnAlternativaA
			// 
			this.btnAlternativaA.BackColor = System.Drawing.Color.White;
			this.btnAlternativaA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnAlternativaA.Location = new System.Drawing.Point(30, 158);
			this.btnAlternativaA.Name = "btnAlternativaA";
			this.btnAlternativaA.Size = new System.Drawing.Size(67, 30);
			this.btnAlternativaA.TabIndex = 1;
			this.btnAlternativaA.Text = "A";
			this.btnAlternativaA.UseVisualStyleBackColor = false;
			this.btnAlternativaA.Click += new System.EventHandler(this.Btn_aClick);
			// 
			// lblPergunta
			// 
			this.lblPergunta.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPergunta.Location = new System.Drawing.Point(65, 11);
			this.lblPergunta.Name = "lblPergunta";
			this.lblPergunta.Size = new System.Drawing.Size(432, 77);
			this.lblPergunta.TabIndex = 0;
			this.lblPergunta.Text = "PERGUNTA";
			this.lblPergunta.Click += new System.EventHandler(this.Label1Click);
			// 
			// btnPergunta1
			// 
			this.btnPergunta1.BackColor = System.Drawing.Color.White;
			this.btnPergunta1.Location = new System.Drawing.Point(21, 404);
			this.btnPergunta1.Name = "btnPergunta1";
			this.btnPergunta1.Size = new System.Drawing.Size(88, 28);
			this.btnPergunta1.TabIndex = 1;
			this.btnPergunta1.Text = "1";
			this.btnPergunta1.UseVisualStyleBackColor = false;
			this.btnPergunta1.Click += new System.EventHandler(this.Btn_1Click);
			// 
			// btnPergunta2
			// 
			this.btnPergunta2.BackColor = System.Drawing.Color.White;
			this.btnPergunta2.Enabled = false;
			this.btnPergunta2.Location = new System.Drawing.Point(115, 404);
			this.btnPergunta2.Name = "btnPergunta2";
			this.btnPergunta2.Size = new System.Drawing.Size(88, 28);
			this.btnPergunta2.TabIndex = 2;
			this.btnPergunta2.Text = "2";
			this.btnPergunta2.UseVisualStyleBackColor = false;
			this.btnPergunta2.Click += new System.EventHandler(this.Btn_2Click);
			// 
			// btnPergunta3
			// 
			this.btnPergunta3.BackColor = System.Drawing.Color.White;
			this.btnPergunta3.Enabled = false;
			this.btnPergunta3.Location = new System.Drawing.Point(209, 404);
			this.btnPergunta3.Name = "btnPergunta3";
			this.btnPergunta3.Size = new System.Drawing.Size(88, 28);
			this.btnPergunta3.TabIndex = 3;
			this.btnPergunta3.Text = "3";
			this.btnPergunta3.UseVisualStyleBackColor = false;
			this.btnPergunta3.Click += new System.EventHandler(this.Btn_3Click);
			// 
			// btnPergunta4
			// 
			this.btnPergunta4.BackColor = System.Drawing.Color.White;
			this.btnPergunta4.Enabled = false;
			this.btnPergunta4.Location = new System.Drawing.Point(303, 404);
			this.btnPergunta4.Name = "btnPergunta4";
			this.btnPergunta4.Size = new System.Drawing.Size(88, 28);
			this.btnPergunta4.TabIndex = 4;
			this.btnPergunta4.Text = "4";
			this.btnPergunta4.UseVisualStyleBackColor = false;
			this.btnPergunta4.Click += new System.EventHandler(this.Btn_4Click);
			// 
			// btnPergunta5
			// 
			this.btnPergunta5.BackColor = System.Drawing.Color.White;
			this.btnPergunta5.Enabled = false;
			this.btnPergunta5.Location = new System.Drawing.Point(397, 404);
			this.btnPergunta5.Name = "btnPergunta5";
			this.btnPergunta5.Size = new System.Drawing.Size(88, 28);
			this.btnPergunta5.TabIndex = 5;
			this.btnPergunta5.Text = "5";
			this.btnPergunta5.UseVisualStyleBackColor = false;
			this.btnPergunta5.Click += new System.EventHandler(this.Btn_5Click);
			// 
			// btnPergunta6
			// 
			this.btnPergunta6.BackColor = System.Drawing.Color.White;
			this.btnPergunta6.Enabled = false;
			this.btnPergunta6.Location = new System.Drawing.Point(492, 404);
			this.btnPergunta6.Name = "btnPergunta6";
			this.btnPergunta6.Size = new System.Drawing.Size(88, 28);
			this.btnPergunta6.TabIndex = 6;
			this.btnPergunta6.Text = "6";
			this.btnPergunta6.UseVisualStyleBackColor = false;
			this.btnPergunta6.Click += new System.EventHandler(this.Btn_6Click);
			// 
			// btnPergunta7
			// 
			this.btnPergunta7.BackColor = System.Drawing.Color.White;
			this.btnPergunta7.Enabled = false;
			this.btnPergunta7.Location = new System.Drawing.Point(586, 404);
			this.btnPergunta7.Name = "btnPergunta7";
			this.btnPergunta7.Size = new System.Drawing.Size(88, 28);
			this.btnPergunta7.TabIndex = 7;
			this.btnPergunta7.Text = "7";
			this.btnPergunta7.UseVisualStyleBackColor = false;
			this.btnPergunta7.Click += new System.EventHandler(this.Btn_7Click);
			// 
			// lblPontos
			// 
			this.lblPontos.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPontos.Location = new System.Drawing.Point(12, 9);
			this.lblPontos.Name = "lblPontos";
			this.lblPontos.Size = new System.Drawing.Size(202, 31);
			this.lblPontos.TabIndex = 8;
			this.lblPontos.Text = "PONTOS: 000";
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(321, 435);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(55, 23);
			this.label1.TabIndex = 10;
			this.label1.Text = "Bônus!";
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(548, 85);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(60, 40);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 11;
			this.pictureBox1.TabStop = false;
			// 
			// lbl_vidas
			// 
			this.lbl_vidas.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_vidas.Location = new System.Drawing.Point(586, 34);
			this.lbl_vidas.Name = "lbl_vidas";
			this.lbl_vidas.Size = new System.Drawing.Size(76, 35);
			this.lbl_vidas.TabIndex = 12;
			this.lbl_vidas.Text = "Vidas:";
			this.lbl_vidas.Click += new System.EventHandler(this.Label2Click);
			// 
			// pictureBox2
			// 
			this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
			this.pictureBox2.Location = new System.Drawing.Point(597, 85);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(60, 40);
			this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox2.TabIndex = 13;
			this.pictureBox2.TabStop = false;
			this.pictureBox2.Click += new System.EventHandler(this.PictureBox2Click);
			// 
			// pictureBox3
			// 
			this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
			this.pictureBox3.Location = new System.Drawing.Point(649, 85);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new System.Drawing.Size(60, 40);
			this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox3.TabIndex = 14;
			this.pictureBox3.TabStop = false;
			// 
			// btnFinalizar
			// 
			this.btnFinalizar.BackColor = System.Drawing.Color.SteelBlue;
			this.btnFinalizar.Enabled = false;
			this.btnFinalizar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnFinalizar.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnFinalizar.ForeColor = System.Drawing.Color.White;
			this.btnFinalizar.Location = new System.Drawing.Point(576, 131);
			this.btnFinalizar.Name = "btnFinalizar";
			this.btnFinalizar.Size = new System.Drawing.Size(101, 32);
			this.btnFinalizar.TabIndex = 15;
			this.btnFinalizar.Text = "Finalizar!";
			this.btnFinalizar.UseVisualStyleBackColor = false;
			this.btnFinalizar.Click += new System.EventHandler(this.Button1Click);
			// 
			// Qmatematica
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.LightSteelBlue;
			this.ClientSize = new System.Drawing.Size(709, 476);
			this.Controls.Add(this.btnFinalizar);
			this.Controls.Add(this.pictureBox3);
			this.Controls.Add(this.pictureBox2);
			this.Controls.Add(this.lbl_vidas);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.lblPontos);
			this.Controls.Add(this.btnPergunta7);
			this.Controls.Add(this.btnPergunta6);
			this.Controls.Add(this.btnPergunta5);
			this.Controls.Add(this.btnPergunta4);
			this.Controls.Add(this.btnPergunta3);
			this.Controls.Add(this.btnPergunta2);
			this.Controls.Add(this.btnPergunta1);
			this.Controls.Add(this.panel1);
			this.Name = "Qmatematica";
			this.Text = "Qmatematica";
			this.panel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Button btnFinalizar;
		private System.Windows.Forms.PictureBox pictureBox3;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.Label lbl_vidas;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label lblPontos;
		private System.Windows.Forms.Button btnAlternativaA;
		private System.Windows.Forms.Button btnAlternativaC;
		private System.Windows.Forms.Button btnAlternativaB;
		private System.Windows.Forms.Button btnAlternativaD;
		private System.Windows.Forms.Label lblTextoA;
		private System.Windows.Forms.Label lblTextoB;
		private System.Windows.Forms.Label lblTextoC;
		private System.Windows.Forms.Label lblTextoD;
		private System.Windows.Forms.Button btnPergunta7;
		private System.Windows.Forms.Button btnPergunta6;
		private System.Windows.Forms.Button btnPergunta5;
		private System.Windows.Forms.Button btnPergunta4;
		private System.Windows.Forms.Button btnPergunta3;
		private System.Windows.Forms.Button btnPergunta2;
		private System.Windows.Forms.Button btnPergunta1;
		private System.Windows.Forms.Label lblPergunta;
		private System.Windows.Forms.Panel panel1;
	}
}
