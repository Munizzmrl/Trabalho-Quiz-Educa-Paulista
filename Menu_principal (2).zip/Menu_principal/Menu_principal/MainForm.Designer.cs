﻿/*
 * Created by SharpDevelop.
 * User: Aluno
 * Date: 06/10/2025
 * Time: 13:12
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Menu_principal
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.gpbx_placar = new System.Windows.Forms.GroupBox();
			this.button1 = new System.Windows.Forms.Button();
			this.lgl_placar = new System.Windows.Forms.Label();
			this.lbl_streak = new System.Windows.Forms.Label();
			this.gpbx_areas = new System.Windows.Forms.GroupBox();
			this.btn_matematica = new System.Windows.Forms.Button();
			this.btn_linguagens = new System.Windows.Forms.Button();
			this.btn_natureza = new System.Windows.Forms.Button();
			this.btn_humanas = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.lbl_titulo2 = new System.Windows.Forms.Label();
			this.btn_sair = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.gpbx_placar.SuspendLayout();
			this.gpbx_areas.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(190, -56);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(496, 335);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox1.TabIndex = 1;
			this.pictureBox1.TabStop = false;
			// 
			// gpbx_placar
			// 
			this.gpbx_placar.BackColor = System.Drawing.SystemColors.MenuBar;
			this.gpbx_placar.Controls.Add(this.button1);
			this.gpbx_placar.Controls.Add(this.lgl_placar);
			this.gpbx_placar.Location = new System.Drawing.Point(531, 304);
			this.gpbx_placar.Name = "gpbx_placar";
			this.gpbx_placar.Size = new System.Drawing.Size(321, 439);
			this.gpbx_placar.TabIndex = 2;
			this.gpbx_placar.TabStop = false;
			this.gpbx_placar.Enter += new System.EventHandler(this.Gpbx_placarEnter);
			// 
			// button1
			// 
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
			this.button1.Location = new System.Drawing.Point(70, 121);
			this.button1.Name = "button1";
			this.button1.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.button1.Size = new System.Drawing.Size(184, 181);
			this.button1.TabIndex = 1;
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.Button1Click);
			// 
			// lgl_placar
			// 
			this.lgl_placar.Font = new System.Drawing.Font("Times New Roman", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lgl_placar.Location = new System.Drawing.Point(24, 16);
			this.lgl_placar.Name = "lgl_placar";
			this.lgl_placar.Size = new System.Drawing.Size(275, 46);
			this.lgl_placar.TabIndex = 0;
			this.lgl_placar.Text = "Acesse o placar!";
			// 
			// lbl_streak
			// 
			this.lbl_streak.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_streak.Location = new System.Drawing.Point(13, 784);
			this.lbl_streak.Name = "lbl_streak";
			this.lbl_streak.Size = new System.Drawing.Size(851, 44);
			this.lbl_streak.TabIndex = 3;
			this.lbl_streak.Text = "label1";
			// 
			// gpbx_areas
			// 
			this.gpbx_areas.BackColor = System.Drawing.SystemColors.Menu;
			this.gpbx_areas.Controls.Add(this.btn_matematica);
			this.gpbx_areas.Controls.Add(this.btn_linguagens);
			this.gpbx_areas.Controls.Add(this.btn_natureza);
			this.gpbx_areas.Controls.Add(this.btn_humanas);
			this.gpbx_areas.Controls.Add(this.label1);
			this.gpbx_areas.Location = new System.Drawing.Point(13, 304);
			this.gpbx_areas.Name = "gpbx_areas";
			this.gpbx_areas.Size = new System.Drawing.Size(334, 439);
			this.gpbx_areas.TabIndex = 3;
			this.gpbx_areas.TabStop = false;
			// 
			// btn_matematica
			// 
			this.btn_matematica.BackColor = System.Drawing.Color.SteelBlue;
			this.btn_matematica.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_matematica.Font = new System.Drawing.Font("MV Boli", 18F, System.Drawing.FontStyle.Bold);
			this.btn_matematica.ForeColor = System.Drawing.Color.Aquamarine;
			this.btn_matematica.Location = new System.Drawing.Point(18, 258);
			this.btn_matematica.Name = "btn_matematica";
			this.btn_matematica.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.btn_matematica.Size = new System.Drawing.Size(297, 58);
			this.btn_matematica.TabIndex = 3;
			this.btn_matematica.Text = "Matemática";
			this.btn_matematica.UseVisualStyleBackColor = false;
			this.btn_matematica.Click += new System.EventHandler(this.Btn_matematicaClick);
			// 
			// btn_linguagens
			// 
			this.btn_linguagens.BackColor = System.Drawing.Color.SteelBlue;
			this.btn_linguagens.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_linguagens.Font = new System.Drawing.Font("MV Boli", 18F, System.Drawing.FontStyle.Bold);
			this.btn_linguagens.ForeColor = System.Drawing.Color.Aquamarine;
			this.btn_linguagens.Location = new System.Drawing.Point(18, 322);
			this.btn_linguagens.Name = "btn_linguagens";
			this.btn_linguagens.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.btn_linguagens.Size = new System.Drawing.Size(297, 58);
			this.btn_linguagens.TabIndex = 3;
			this.btn_linguagens.Text = "Linguagens";
			this.btn_linguagens.UseVisualStyleBackColor = false;
			this.btn_linguagens.Click += new System.EventHandler(this.Btn_linguagensClick);
			// 
			// btn_natureza
			// 
			this.btn_natureza.BackColor = System.Drawing.Color.SteelBlue;
			this.btn_natureza.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_natureza.Font = new System.Drawing.Font("MV Boli", 18F, System.Drawing.FontStyle.Bold);
			this.btn_natureza.ForeColor = System.Drawing.Color.Aquamarine;
			this.btn_natureza.Location = new System.Drawing.Point(18, 194);
			this.btn_natureza.Name = "btn_natureza";
			this.btn_natureza.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.btn_natureza.Size = new System.Drawing.Size(297, 58);
			this.btn_natureza.TabIndex = 2;
			this.btn_natureza.Text = "Ciências da Natureza";
			this.btn_natureza.UseVisualStyleBackColor = false;
			this.btn_natureza.Click += new System.EventHandler(this.Btn_naturezaClick);
			// 
			// btn_humanas
			// 
			this.btn_humanas.BackColor = System.Drawing.Color.SteelBlue;
			this.btn_humanas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_humanas.Font = new System.Drawing.Font("MV Boli", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btn_humanas.ForeColor = System.Drawing.Color.Aquamarine;
			this.btn_humanas.Location = new System.Drawing.Point(18, 135);
			this.btn_humanas.Name = "btn_humanas";
			this.btn_humanas.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.btn_humanas.Size = new System.Drawing.Size(297, 53);
			this.btn_humanas.TabIndex = 1;
			this.btn_humanas.Text = "Ciências Humanas";
			this.btn_humanas.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			this.btn_humanas.UseVisualStyleBackColor = false;
			this.btn_humanas.Click += new System.EventHandler(this.Btn_humanasClick);
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Times New Roman", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(6, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(309, 87);
			this.label1.TabIndex = 0;
			this.label1.Text = "Áreas do\r\n conhecimento!";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBox2
			// 
			this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
			this.pictureBox2.Location = new System.Drawing.Point(723, 749);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(129, 88);
			this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox2.TabIndex = 4;
			this.pictureBox2.TabStop = false;
			// 
			// lbl_titulo2
			// 
			this.lbl_titulo2.BackColor = System.Drawing.Color.LightSteelBlue;
			this.lbl_titulo2.Font = new System.Drawing.Font("Cooper Black", 54F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_titulo2.Location = new System.Drawing.Point(303, 230);
			this.lbl_titulo2.Name = "lbl_titulo2";
			this.lbl_titulo2.Size = new System.Drawing.Size(279, 71);
			this.lbl_titulo2.TabIndex = 15;
			this.lbl_titulo2.Text = "Início!";
			this.lbl_titulo2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btn_sair
			// 
			this.btn_sair.BackColor = System.Drawing.Color.Red;
			this.btn_sair.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btn_sair.Location = new System.Drawing.Point(12, 12);
			this.btn_sair.Name = "btn_sair";
			this.btn_sair.Size = new System.Drawing.Size(75, 23);
			this.btn_sair.TabIndex = 16;
			this.btn_sair.Text = "Sair";
			this.btn_sair.UseVisualStyleBackColor = false;
			this.btn_sair.Click += new System.EventHandler(this.Btn_sairClick);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.LightSteelBlue;
			this.ClientSize = new System.Drawing.Size(864, 839);
			this.Controls.Add(this.btn_sair);
			this.Controls.Add(this.lbl_titulo2);
			this.Controls.Add(this.pictureBox2);
			this.Controls.Add(this.gpbx_areas);
			this.Controls.Add(this.lbl_streak);
			this.Controls.Add(this.gpbx_placar);
			this.Controls.Add(this.pictureBox1);
			this.Margin = new System.Windows.Forms.Padding(2);
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Menu_principal";
			this.Load += new System.EventHandler(this.MainFormLoad);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.gpbx_placar.ResumeLayout(false);
			this.gpbx_areas.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Button btn_sair;
		private System.Windows.Forms.Label lbl_titulo2;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btn_humanas;
		private System.Windows.Forms.Button btn_natureza;
		private System.Windows.Forms.Button btn_linguagens;
		private System.Windows.Forms.Button btn_matematica;
		private System.Windows.Forms.GroupBox gpbx_areas;
		private System.Windows.Forms.Label lbl_streak;
		private System.Windows.Forms.Label lgl_placar;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.GroupBox gpbx_placar;
		private System.Windows.Forms.PictureBox pictureBox1;
	}
}
